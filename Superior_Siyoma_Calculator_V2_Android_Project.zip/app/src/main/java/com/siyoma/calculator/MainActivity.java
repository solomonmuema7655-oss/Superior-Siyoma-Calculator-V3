package com.siyoma.calculator;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.TextView;
import android.widget.LinearLayout;

/*
 * V2 Android shell.
 * The Python/Kivy source is included in the project as the calculator
 * implementation source and is used by the Android packaging workflow.
 */
public class MainActivity extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER);
        layout.setBackgroundColor(Color.rgb(10,10,10));

        TextView title = new TextView(this);
        title.setText("SUPERIOR SIYOMA\nSCIENTIFIC CALCULATOR V2");
        title.setTextColor(Color.WHITE);
        title.setTextSize(24);
        title.setGravity(Gravity.CENTER);
        layout.addView(title);

        TextView info = new TextView(this);
        info.setText("\nPython/Kivy V2 source is included.\nBuild through the configured Android workflow.");
        info.setTextColor(Color.LTGRAY);
        info.setTextSize(14);
        info.setGravity(Gravity.CENTER);
        layout.addView(info);

        setContentView(layout);
    }
}
