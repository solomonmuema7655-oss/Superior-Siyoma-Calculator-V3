# ============================================================
# SUPERIOR SIYOMA SCIENTIFIC CALCULATOR V2
# ============================================================
# Copyright © 2026 SiyomaCodingPrograms
# ============================================================

import math
import random
from kivy.app import App
from kivy.core.window import Window
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.scrollview import ScrollView

class CalculatorEngine:
    def __init__(self):
        self.memory = 0
        self.answer = 0
        self.degrees = True
        self.history = []

    def nPr(self, n, r):
        n, r = int(n), int(r)
        if n < 0 or r < 0 or r > n: raise ValueError
        return math.factorial(n) // math.factorial(n-r)

    def nCr(self, n, r):
        n, r = int(n), int(r)
        if n < 0 or r < 0 or r > n: raise ValueError
        return math.factorial(n) // (math.factorial(r)*math.factorial(n-r))

    def sin(self,x): return math.sin(math.radians(x) if self.degrees else x)
    def cos(self,x): return math.cos(math.radians(x) if self.degrees else x)
    def tan(self,x): return math.tan(math.radians(x) if self.degrees else x)

    def asin(self,x):
        r=math.asin(x); return math.degrees(r) if self.degrees else r
    def acos(self,x):
        r=math.acos(x); return math.degrees(r) if self.degrees else r
    def atan(self,x):
        r=math.atan(x); return math.degrees(r) if self.degrees else r

    def root(self,x,n):
        if n == 0 or (x < 0 and n % 2 == 0): raise ValueError
        return -((-x)**(1/n)) if x < 0 else x**(1/n)

    def calculate(self, expression):
        try:
            expression = expression.replace("×","*").replace("÷","/").replace("^","**").replace("π","pi")
            allowed = {
                "pi":math.pi, "e":math.e, "sqrt":math.sqrt, "abs":abs,
                "log":math.log10, "ln":math.log, "factorial":math.factorial,
                "nPr":self.nPr, "nCr":self.nCr,
                "sin":self.sin, "cos":self.cos, "tan":self.tan,
                "asin":self.asin, "acos":self.acos, "atan":self.atan,
                "sinh":math.sinh, "cosh":math.cosh, "tanh":math.tanh,
                "asinh":math.asinh, "acosh":math.acosh, "atanh":math.atanh,
                "root":self.root, "pow":pow
            }
            result = eval(expression, {"__builtins__":{}}, allowed)
            self.answer = result
            self.history.append(f"{expression} = {result}")
            return result
        except ZeroDivisionError: return "ERROR: Division by zero"
        except ValueError: return "ERROR: Invalid value"
        except OverflowError: return "ERROR: Number too large"
        except Exception: return "ERROR"

class SuperiorCalculator(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(orientation="vertical", spacing=dp(3), padding=dp(6), **kwargs)
        self.engine=CalculatorEngine()

        self.add_widget(Label(text="[b]SIYOMA CALCULATOR FOR MACHAKOS UNIVERSITY STUDENTS[/b]",
                              markup=True,font_size=dp(17),size_hint_y=None,height=dp(45)))
        self.display=TextInput(multiline=False,font_size=dp(24),halign="right",
                                size_hint_y=None,height=dp(65))
        self.add_widget(self.display)

        info=BoxLayout(size_hint_y=None,height=dp(34))
        self.mode=Button(text="DEG")
        self.mode.bind(on_press=self.toggle_mode)
        info.add_widget(self.mode)
        self.ans=Label(text="Ans: 0")
        info.add_widget(self.ans)
        self.add_widget(info)

        grid=GridLayout(cols=5,spacing=dp(2))
        buttons=[
            "MC","MR","M+","M-","AC",
            "sin","cos","tan","asin","acos",
            "atan","sinh","cosh","tanh","√",
            "nPr","nCr","n!","x²","xʸ",
            "root","1/x","|x|","%","log",
            "ln","π","e","(",")",
            "7","8","9","÷","⌫",
            "4","5","6","×","^",
            "1","2","3","-","RAND",
            "0",".","=","+","Ans",
            "asinh","acosh","atanh","HISTORY","C"
        ]
        for text in buttons:
            b=Button(text=text,font_size=dp(13))
            b.bind(on_press=self.button_pressed)
            grid.add_widget(b)
        self.add_widget(grid)

        self.add_widget(Label(text="[b]CALCULATION HISTORY[/b]",markup=True,size_hint_y=None,height=dp(23)))
        scroll=ScrollView(size_hint_y=None,height=dp(60))
        self.history_label=Label(text="",size_hint_y=None,halign="left",valign="top")
        self.history_label.bind(texture_size=self.history_label.setter("size"))
        scroll.add_widget(self.history_label)
        self.add_widget(scroll)
        self.add_widget(Label(text="© 2026 SiyomaCodingPrograms",font_size=dp(10),size_hint_y=None,height=dp(20)))

    def button_pressed(self,b):
        v=b.text
        if v in ("AC","C"): self.display.text=""; return
        if v=="⌫": self.display.text=self.display.text[:-1]; return
        if v=="MC": self.engine.memory=0; return
        if v=="MR": self.display.text+=str(self.engine.memory); return
        if v in ("M+","M-"):
            r=self.engine.calculate(self.display.text)
            if isinstance(r,(int,float)): self.engine.memory += r if v=="M+" else -r
            return
        if v=="Ans": self.display.text+=str(self.engine.answer); return
        if v=="RAND": self.display.text+=str(random.random()); return
        if v=="HISTORY": self.update_history(); return
        if v=="n!": self.display.text+="factorial("; return
        if v=="√": self.display.text+="sqrt("; return
        if v=="|x|": self.display.text+="abs("; return
        if v=="1/x":
            self.display.text=f"1/({self.display.text})"; return
        if v=="x²":
            self.display.text=f"({self.display.text})**2"; return
        if v=="xʸ": self.display.text+="^"; return
        if v=="root": self.display.text+="root("; return
        if v=="%": self.display.text+="/100"; return
        if v in ["sin","cos","tan","asin","acos","atan","sinh","cosh","tanh","asinh","acosh","atanh","log","ln","nPr","nCr"]:
            self.display.text+=v+"("; return
        if v=="=":
            r=self.engine.calculate(self.display.text)
            if isinstance(r,float):
                r=int(r) if r.is_integer() else round(r,10)
            self.display.text=str(r); self.ans.text=f"Ans: {r}"; self.update_history(); return
        self.display.text+=v

    def toggle_mode(self,_):
        self.engine.degrees=not self.engine.degrees
        self.mode.text="DEG" if self.engine.degrees else "RAD"

    def update_history(self):
        self.history_label.text="\n".join(self.engine.history[-10:])

class SuperiorCalculatorApp(App):
    def build(self):
        Window.clearcolor=(0.04,0.04,0.04,1)
        return SuperiorCalculator()

if __name__=="__main__":
    SuperiorCalculatorApp().run()
