# SUPERIOR SIYOMA SCIENTIFIC CALCULATOR V2

Python/Kivy Android calculator project.

Build architecture is intentionally kept simple and suitable for the proven GitHub Actions route:
- Ubuntu 22.04 runner
- Java 17
- Gradle 8.7
- Android SDK
- Kivy + Python-for-Android
- Debug APK output

App branding:
SIYOMA CALCULATOR FOR MACHAKOS UNIVERSITY STUDENTS
Copyright © 2026 SiyomaCodingPrograms
